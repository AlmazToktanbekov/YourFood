# Food-App-Android-Design

how to make food order app in android studio with android studio XML code ?
In this food app android , we have sections that include a list of categories of foods, popular foods, details of each food, Intro page and shopping cart.


https://user-images.githubusercontent.com/87927632/177328456-25665a96-2a3b-4bd7-acd3-b38247236fcd.mp4

